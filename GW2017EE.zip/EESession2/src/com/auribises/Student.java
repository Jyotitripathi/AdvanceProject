package com.auribises;

public class Student {

	String name;
	
	public Student() {
		name = "NA";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
