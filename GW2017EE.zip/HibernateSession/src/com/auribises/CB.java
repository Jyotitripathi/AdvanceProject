package com.auribises;

public class CB extends CA{ // IS-A
	
	Integer b;

	public Integer getB() {
		return b;
	}

	public void setB(Integer b) {
		this.b = b;
	}
	
	
}
