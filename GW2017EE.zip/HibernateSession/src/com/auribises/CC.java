package com.auribises;

public class CC extends CB{
	
	Integer c;

	public Integer getC() {
		return c;
	}

	public void setC(Integer c) {
		this.c = c;
	}
	
}
