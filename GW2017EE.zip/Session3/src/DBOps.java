
public interface DBOps {
	void insert(); // pubic abstract void insert();
	void delete();
	void update();
	void retrieve();
}


