package com.auribises;

public class Seed {

	public void showSeed(){
		System.out.println("The seed is black in color");
	}
	
}
